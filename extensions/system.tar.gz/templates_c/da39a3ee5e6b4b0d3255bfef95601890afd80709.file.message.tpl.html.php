<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-11-21 01:45:40
         compiled from "pfmextension://system/templates/message.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:1199383026564fa2944181d9-00633806%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'da39a3ee5e6b4b0d3255bfef95601890afd80709' => 
    array (
      0 => 'pfmextension://system/templates/message.tpl.html',
      1 => 1447875150,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1199383026564fa2944181d9-00633806',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'class' => 0,
    'message' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_564fa2944c4c89_49004464',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_564fa2944c4c89_49004464')) {function content_564fa2944c4c89_49004464($_smarty_tpl) {?><div class="<?php echo $_smarty_tpl->tpl_vars['class']->value;?>
">
    <?php echo $_smarty_tpl->tpl_vars['message']->value;?>

</div><?php }} ?>
