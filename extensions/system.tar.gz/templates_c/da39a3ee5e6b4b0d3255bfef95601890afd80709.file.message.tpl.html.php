<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-09-13 21:41:29
         compiled from "pfmextension://system/templates/message.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:131387398955f5c3597a01a6-50622345%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'da39a3ee5e6b4b0d3255bfef95601890afd80709' => 
    array (
      0 => 'pfmextension://system/templates/message.tpl.html',
      1 => 1442168046,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '131387398955f5c3597a01a6-50622345',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'class' => 0,
    'message' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_55f5c35984d244_90574070',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55f5c35984d244_90574070')) {function content_55f5c35984d244_90574070($_smarty_tpl) {?><div class="<?php echo $_smarty_tpl->tpl_vars['class']->value;?>
">
    <?php echo $_smarty_tpl->tpl_vars['message']->value;?>

</div><?php }} ?>
