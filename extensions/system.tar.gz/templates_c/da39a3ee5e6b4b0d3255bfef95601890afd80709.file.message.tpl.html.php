<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-07-19 14:47:12
         compiled from "pfmextension://system/templates/message.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:22999320755ab8e40664ce8-35744577%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'da39a3ee5e6b4b0d3255bfef95601890afd80709' => 
    array (
      0 => 'pfmextension://system/templates/message.tpl.html',
      1 => 1437303318,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '22999320755ab8e40664ce8-35744577',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'class' => 0,
    'message' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_55ab8e40674217_43805840',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55ab8e40674217_43805840')) {function content_55ab8e40674217_43805840($_smarty_tpl) {?><div class="<?php echo $_smarty_tpl->tpl_vars['class']->value;?>
">
    <?php echo $_smarty_tpl->tpl_vars['message']->value;?>

</div><?php }} ?>
