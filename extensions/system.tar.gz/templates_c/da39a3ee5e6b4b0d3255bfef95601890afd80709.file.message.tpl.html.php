<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-05-25 21:57:25
         compiled from "pfmextension://system/templates/message.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:62474723455637095d9db03-60916396%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'da39a3ee5e6b4b0d3255bfef95601890afd80709' => 
    array (
      0 => 'pfmextension://system/templates/message.tpl.html',
      1 => 1432474151,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '62474723455637095d9db03-60916396',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'class' => 0,
    'message' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_55637095deee41_30272047',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55637095deee41_30272047')) {function content_55637095deee41_30272047($_smarty_tpl) {?><div class="<?php echo $_smarty_tpl->tpl_vars['class']->value;?>
">
    <?php echo $_smarty_tpl->tpl_vars['message']->value;?>

</div><?php }} ?>
