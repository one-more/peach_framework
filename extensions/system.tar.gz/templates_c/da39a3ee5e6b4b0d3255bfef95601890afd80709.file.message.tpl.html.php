<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-04-11 13:33:10
         compiled from "pfmextension://system/templates/message.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:6930303195528f86694ed37-05361005%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'da39a3ee5e6b4b0d3255bfef95601890afd80709' => 
    array (
      0 => 'pfmextension://system/templates/message.tpl.html',
      1 => 1428693464,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6930303195528f86694ed37-05361005',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'class' => 0,
    'message' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5528f86695be53_49043964',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5528f86695be53_49043964')) {function content_5528f86695be53_49043964($_smarty_tpl) {?><div class="<?php echo $_smarty_tpl->tpl_vars['class']->value;?>
">
    <?php echo $_smarty_tpl->tpl_vars['message']->value;?>

</div><?php }} ?>
