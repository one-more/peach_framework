<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-09-13 23:31:43
         compiled from "pfmextension://tools/templates/menu/left_menu.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:10312084255f5dd2fadea77-84657039%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'da39a3ee5e6b4b0d3255bfef95601890afd80709' => 
    array (
      0 => 'pfmextension://tools/templates/menu/left_menu.tpl.html',
      1 => 1442176291,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '10312084255f5dd2fadea77-84657039',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'uri' => 0,
    'class' => 0,
    'HTML' => 0,
    'lang_vars' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_55f5dd2faf9d94_04466123',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55f5dd2faf9d94_04466123')) {function content_55f5dd2faf9d94_04466123($_smarty_tpl) {?><div id="left-menu">
    <ul id="tools-menu" class="nav nav-stacked nav-pills">
        <?php if ($_smarty_tpl->tpl_vars['uri']->value=='/') {?>
            <?php $_smarty_tpl->tpl_vars['class'] = new Smarty_variable('active', null, 0);?>
        <?php } else { ?>
            <?php $_smarty_tpl->tpl_vars['class'] = new Smarty_variable(null, null, 0);?>
        <?php }?>
        <?php echo $_smarty_tpl->tpl_vars['HTML']->value->begin_tag('li',array('class'=>$_smarty_tpl->tpl_vars['class']->value));?>

            <a href="/"><?php echo $_smarty_tpl->tpl_vars['lang_vars']->value['templates'];?>
</a>
        <?php echo $_smarty_tpl->tpl_vars['HTML']->value->end_tag('li');?>

    </ul>
</div><?php }} ?>
