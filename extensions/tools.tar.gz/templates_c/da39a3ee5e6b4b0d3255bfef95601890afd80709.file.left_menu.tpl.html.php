<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-10-23 02:33:58
         compiled from "pfmextension://tools/templates/menu/left_menu.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:142915365656297266b95aa8-73266789%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'da39a3ee5e6b4b0d3255bfef95601890afd80709' => 
    array (
      0 => 'pfmextension://tools/templates/menu/left_menu.tpl.html',
      1 => 1445556838,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '142915365656297266b95aa8-73266789',
  'function' => 
  array (
    'is_templates_active' => 
    array (
      'parameter' => 
      array (
        'uri' => '',
      ),
      'compiled' => '',
    ),
  ),
  'variables' => 
  array (
    'uri' => 0,
    'lang_vars' => 0,
  ),
  'has_nocache_code' => 0,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56297266ba5c59_25788979',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56297266ba5c59_25788979')) {function content_56297266ba5c59_25788979($_smarty_tpl) {?><?php if (!function_exists('smarty_template_function_is_templates_active')) {
    function smarty_template_function_is_templates_active($_smarty_tpl,$params) {
    $saved_tpl_vars = $_smarty_tpl->tpl_vars;
    foreach ($_smarty_tpl->smarty->template_functions['is_templates_active']['parameter'] as $key => $value) {$_smarty_tpl->tpl_vars[$key] = new Smarty_variable($value);};
    foreach ($params as $key => $value) {$_smarty_tpl->tpl_vars[$key] = new Smarty_variable($value);}?>
    <?php if ($_smarty_tpl->tpl_vars['uri']->value=='/') {?>
        active
    <?php }?>
<?php $_smarty_tpl->tpl_vars = $saved_tpl_vars;
foreach (Smarty::$global_tpl_vars as $key => $value) if(!isset($_smarty_tpl->tpl_vars[$key])) $_smarty_tpl->tpl_vars[$key] = $value;}}?>

<div id="left-menu">
    <ul id="tools-menu" class="nav nav-stacked nav-pills">
        <li class="<?php smarty_template_function_is_templates_active($_smarty_tpl,array('uri'=>$_smarty_tpl->tpl_vars['uri']->value));?>
">
            <a href="/"><?php echo $_smarty_tpl->tpl_vars['lang_vars']->value['templates'];?>
</a>
        </li>
    </ul>
</div><?php }} ?>
