<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-04-22 23:53:27
         compiled from "pfmextension://tools/templates/menu/left_menu.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:209355363455380a473ce9f4-60107974%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'da39a3ee5e6b4b0d3255bfef95601890afd80709' => 
    array (
      0 => 'pfmextension://tools/templates/menu/left_menu.tpl.html',
      1 => 1429736007,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '209355363455380a473ce9f4-60107974',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'uri' => 0,
    'templates' => 0,
    'node_processes' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_55380a473e5387_14309978',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55380a473e5387_14309978')) {function content_55380a473e5387_14309978($_smarty_tpl) {?><div id="left-menu">
    <ul id="tools-menu" class="nav nav-stacked nav-pills">
        <li <?php if ($_smarty_tpl->tpl_vars['uri']->value=='/') {?> class="active"<?php }?>>
        <a href="/"><?php echo $_smarty_tpl->tpl_vars['templates']->value;?>
</a>
        </li>
        <li <?php if ($_smarty_tpl->tpl_vars['uri']->value=='/node_processes') {?> class="active"<?php }?>>
        <a href="/node_processes"><?php echo $_smarty_tpl->tpl_vars['node_processes']->value;?>
</a>
        </li>
    </ul>
</div><?php }} ?>
