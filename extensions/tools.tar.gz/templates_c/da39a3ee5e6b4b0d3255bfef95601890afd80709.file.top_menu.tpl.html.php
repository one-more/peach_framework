<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-07-19 20:50:32
         compiled from "pfmextension://tools/templates/menu/top_menu.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:102292959155abe3686da3a4-91430547%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'da39a3ee5e6b4b0d3255bfef95601890afd80709' => 
    array (
      0 => 'pfmextension://tools/templates/menu/top_menu.tpl.html',
      1 => 1436516141,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '102292959155abe3686da3a4-91430547',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'tools' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_55abe3686e2bc4_18326735',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55abe3686e2bc4_18326735')) {function content_55abe3686e2bc4_18326735($_smarty_tpl) {?><ul class="nav navbar-nav">
    <li class="active">
        <a href="/"><?php echo $_smarty_tpl->tpl_vars['tools']->value;?>
</a>
    </li>
</ul><?php }} ?>
