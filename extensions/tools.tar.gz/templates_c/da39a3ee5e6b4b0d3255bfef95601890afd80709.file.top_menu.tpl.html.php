<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-09-10 01:44:54
         compiled from "pfmextension://tools/templates/menu/top_menu.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:161466941355f0b66627ed01-04471285%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'da39a3ee5e6b4b0d3255bfef95601890afd80709' => 
    array (
      0 => 'pfmextension://tools/templates/menu/top_menu.tpl.html',
      1 => 1441838661,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '161466941355f0b66627ed01-04471285',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'lang_vars' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_55f0b666286314_68913574',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55f0b666286314_68913574')) {function content_55f0b666286314_68913574($_smarty_tpl) {?><ul class="nav navbar-nav">
    <li class="active">
        <a href="/"><?php echo $_smarty_tpl->tpl_vars['lang_vars']->value['tools'];?>
</a>
    </li>
</ul><?php }} ?>
