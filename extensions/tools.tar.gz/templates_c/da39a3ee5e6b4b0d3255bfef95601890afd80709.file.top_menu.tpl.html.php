<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-10-23 02:33:58
         compiled from "pfmextension://tools/templates/menu/top_menu.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:170420474756297266bd1761-02510387%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'da39a3ee5e6b4b0d3255bfef95601890afd80709' => 
    array (
      0 => 'pfmextension://tools/templates/menu/top_menu.tpl.html',
      1 => 1445556838,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '170420474756297266bd1761-02510387',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'lang_vars' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56297266bd9807_38318553',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56297266bd9807_38318553')) {function content_56297266bd9807_38318553($_smarty_tpl) {?><ul class="nav navbar-nav">
    <li class="active">
        <a href="/"><?php echo $_smarty_tpl->tpl_vars['lang_vars']->value['tools'];?>
</a>
    </li>
</ul><?php }} ?>
