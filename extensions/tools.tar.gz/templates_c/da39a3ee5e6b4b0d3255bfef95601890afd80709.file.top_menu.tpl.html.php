<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-09-13 23:31:43
         compiled from "pfmextension://tools/templates/menu/top_menu.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:16221953355f5dd2fb26da2-91343667%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'da39a3ee5e6b4b0d3255bfef95601890afd80709' => 
    array (
      0 => 'pfmextension://tools/templates/menu/top_menu.tpl.html',
      1 => 1442176291,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '16221953355f5dd2fb26da2-91343667',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'lang_vars' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_55f5dd2fb2eaa0_00196167',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55f5dd2fb2eaa0_00196167')) {function content_55f5dd2fb2eaa0_00196167($_smarty_tpl) {?><ul class="nav navbar-nav">
    <li class="active">
        <a href="/"><?php echo $_smarty_tpl->tpl_vars['lang_vars']->value['tools'];?>
</a>
    </li>
</ul><?php }} ?>
