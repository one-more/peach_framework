<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-04-21 23:57:01
         compiled from "pfmextension://tools/templates/node_processes/node_processes_table.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:7857483635536b99d8d6361-16818415%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'da39a3ee5e6b4b0d3255bfef95601890afd80709' => 
    array (
      0 => 'pfmextension://tools/templates/node_processes/node_processes_table.tpl.html',
      1 => 1429649821,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '7857483635536b99d8d6361-16818415',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'processes' => 0,
    'process' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5536b99d8ff163_35782762',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5536b99d8ff163_35782762')) {function content_5536b99d8ff163_35782762($_smarty_tpl) {?><?php if (count($_smarty_tpl->tpl_vars['processes']->value)) {?>
<table id="node-processes-table" class="table table-striped">
    <thead>
        <th>Name</th>
        <th>Enabled</th>
        <th></th>
    </thead>
    <tbody>
        <?php  $_smarty_tpl->tpl_vars['process'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['process']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['processes']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['process']->key => $_smarty_tpl->tpl_vars['process']->value) {
$_smarty_tpl->tpl_vars['process']->_loop = true;
?>
            <tr>
                <td><?php echo $_smarty_tpl->tpl_vars['process']->value['name'];?>
</td>
                <td>
                    <?php if ($_smarty_tpl->tpl_vars['process']->value['enabled']) {?>
                        <span class="glyphicon glyphicon-ok"></span>
                    <?php } else { ?>
                        <span class="glyphicon glyphicon-remove"></span>
                    <?php }?>
                </td>
                <td width="30" class="toggle-process">
                    <?php if ($_smarty_tpl->tpl_vars['process']->value['enabled']) {?>
                        <button data-process="static-builder" data-action="disable" class="btn btn-danger btn-xs">disable</button>
                    <?php } else { ?>
                        <button data-process="static-builder" data-action="enable" class="btn btn-success btn-xs">enable</button>
                    <?php }?>
                </td>
            </tr>
        <?php } ?>
    </tbody>
</table>
<?php }?><?php }} ?>
