<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-04-10 22:42:30
         compiled from "pfmextension://tools/templates/index/index.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:1641587892552827a6389519-47898062%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'da39a3ee5e6b4b0d3255bfef95601890afd80709' => 
    array (
      0 => 'pfmextension://tools/templates/index/index.tpl.html',
      1 => 1428694950,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1641587892552827a6389519-47898062',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'css_path' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_552827a639da13_33396492',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_552827a639da13_33396492')) {function content_552827a639da13_33396492($_smarty_tpl) {?><!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['css_path']->value;?>
/tools.css"/>
    </head>
    <body>
        <h1>Tools</h1>
    </body>
</html>
<?php }} ?>
