<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-04-18 00:53:06
         compiled from "pfmextension://tools/templates/index/index.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:583622879553180c2d6e8a1-43094580%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'da39a3ee5e6b4b0d3255bfef95601890afd80709' => 
    array (
      0 => 'pfmextension://tools/templates/index/index.tpl.html',
      1 => 1429307586,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '583622879553180c2d6e8a1-43094580',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'css_path' => 0,
    'images_path' => 0,
    'uri' => 0,
    'main_content' => 0,
    'js_path' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_553180c2d851a2_01102746',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_553180c2d851a2_01102746')) {function content_553180c2d851a2_01102746($_smarty_tpl) {?><!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['css_path']->value;?>
/tools.css"/>
        <link rel="shortcut icon" href="<?php echo $_smarty_tpl->tpl_vars['images_path']->value;?>
/favicon.ico"/>
    </head>
    <body>
        <div id="all">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-10 col-lg-offset-1">
                        <nav class="navbar navbar-inverse">
                            <div class="container-fluid">
                                <div class="navbar-header">
                                    <a class="navbar-brand" href="/">Peach Framework</a>
                                </div>
                                <div class="collapse navbar-collapse">
                                    <ul class="nav navbar-nav">
                                        <li class="active">
                                            <a href="/">tools</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </nav>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-2 col-lg-offset-1">
                        <ul class="nav nav-stacked nav-pills">
                            <li <?php if ($_smarty_tpl->tpl_vars['uri']->value=='/') {?> class="active"<?php }?>>
                                <a href="/">Templates tool</a>
                            </li>
                            <li <?php if ($_smarty_tpl->tpl_vars['uri']->value=='/node_processes') {?> class="active"<?php }?>>
                                <a href="/node_processes">Node processes</a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-lg-8">
                        <?php echo $_smarty_tpl->tpl_vars['main_content']->value;?>

                    </div>
                </div>
            </div>
        </div>
        <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['js_path']->value;?>
/tools.js"><?php echo '</script'; ?>
>
    </body>
</html>
<?php }} ?>
