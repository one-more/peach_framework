<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-10-23 02:33:58
         compiled from "pfmextension://tools/templates/templates/templates_table.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:174409028656297266b3aca9-83487780%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'da39a3ee5e6b4b0d3255bfef95601890afd80709' => 
    array (
      0 => 'pfmextension://tools/templates/templates/templates_table.tpl.html',
      1 => 1445556838,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '174409028656297266b3aca9-83487780',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'lang_vars' => 0,
    'templates_list' => 0,
    'template' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56297266b672b6_63198372',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56297266b672b6_63198372')) {function content_56297266b672b6_63198372($_smarty_tpl) {?><table class="table table-striped">
    <thead>
    <tr>
        <th><?php echo $_smarty_tpl->tpl_vars['lang_vars']->value['name'];?>
</th>
    </tr>
    </thead>
    <?php  $_smarty_tpl->tpl_vars['template'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['template']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['templates_list']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['template']->key => $_smarty_tpl->tpl_vars['template']->value) {
$_smarty_tpl->tpl_vars['template']->_loop = true;
?>
    <tr>
        <td>
            <?php echo $_smarty_tpl->tpl_vars['template']->value['name'];?>

        </td>
    </tr>
    <?php } ?>
</table><?php }} ?>
