<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-04-22 23:57:03
         compiled from "pfmextension://tools/templates/templates/templates_table.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:133850943855380b1f860df1-55425865%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'da39a3ee5e6b4b0d3255bfef95601890afd80709' => 
    array (
      0 => 'pfmextension://tools/templates/templates/templates_table.tpl.html',
      1 => 1429736007,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '133850943855380b1f860df1-55425865',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'templates_list' => 0,
    'name' => 0,
    'template' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_55380b1f87ddb1_22255672',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55380b1f87ddb1_22255672')) {function content_55380b1f87ddb1_22255672($_smarty_tpl) {?><?php if (count($_smarty_tpl->tpl_vars['templates_list']->value)) {?>
    <table class="table table-striped">
        <thead>
            <tr>
                <th><?php echo $_smarty_tpl->tpl_vars['name']->value;?>
</th>
            </tr>
        </thead>
        <?php  $_smarty_tpl->tpl_vars['template'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['template']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['templates_list']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['template']->key => $_smarty_tpl->tpl_vars['template']->value) {
$_smarty_tpl->tpl_vars['template']->_loop = true;
?>
            <tr>
                <td>
                    <?php echo $_smarty_tpl->tpl_vars['template']->value['name'];?>

                </td>
            </tr>
        <?php } ?>
    </table>
<?php }?><?php }} ?>
