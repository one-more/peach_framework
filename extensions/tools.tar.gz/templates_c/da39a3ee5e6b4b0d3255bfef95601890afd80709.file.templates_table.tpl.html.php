<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-04-18 00:53:11
         compiled from "pfmextension://tools/templates/templates/templates_table.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:866499075553180c7177b81-10567216%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'da39a3ee5e6b4b0d3255bfef95601890afd80709' => 
    array (
      0 => 'pfmextension://tools/templates/templates/templates_table.tpl.html',
      1 => 1429307586,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '866499075553180c7177b81-10567216',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'templates_list' => 0,
    'template' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_553180c71a71a9_66213294',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_553180c71a71a9_66213294')) {function content_553180c71a71a9_66213294($_smarty_tpl) {?><?php if (count($_smarty_tpl->tpl_vars['templates_list']->value)) {?>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Name</th>
            </tr>
        </thead>
        <?php  $_smarty_tpl->tpl_vars['template'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['template']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['templates_list']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['template']->key => $_smarty_tpl->tpl_vars['template']->value) {
$_smarty_tpl->tpl_vars['template']->_loop = true;
?>
            <tr>
                <td>
                    <?php echo $_smarty_tpl->tpl_vars['template']->value['name'];?>

                </td>
            </tr>
        <?php } ?>
    </table>
    <button type="button" class="btn btn-primary">Create template</button>
<?php }?><?php }} ?>
