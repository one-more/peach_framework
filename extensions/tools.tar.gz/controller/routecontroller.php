<?php

class RouteController extends Router {
	protected $routes;

	public function __construct() {
		$this->routes = [
			'/' => [$this, 'index']
		];
	}

	public function index() {
		echo 'tools<br>';
	}
}