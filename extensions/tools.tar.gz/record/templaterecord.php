<?php

namespace Tools\record;

/**
 * Class TemplateRecord
 *
 * @property string name
 * @property bool can_delete
 */
class TemplateRecord extends \RecordSet {}